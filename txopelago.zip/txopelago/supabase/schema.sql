-- ============================================================
-- TXOPELAGO MOZ — schema do banco de dados (Supabase / Postgres)
-- Rode este arquivo inteiro em: Supabase > SQL Editor > New query
-- ============================================================

create extension if not exists "pgcrypto";

-- ------------------------------------------------------------
-- PERFIS (um por pessoa cadastrada — passageiro ou motorista)
-- ------------------------------------------------------------
create table if not exists perfis (
  id uuid primary key references auth.users(id) on delete cascade,
  nome text,
  telefone text,
  tipo text not null default 'passageiro', -- passageiro | motorista
  created_at timestamptz default now()
);

create or replace function public.criar_perfil_novo_usuario()
returns trigger as $$
begin
  insert into public.perfis (id, nome, telefone, tipo)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'nome', ''),
    coalesce(new.raw_user_meta_data->>'telefone', ''),
    coalesce(new.raw_user_meta_data->>'tipo', 'passageiro')
  )
  on conflict (id) do nothing;
  return new;
end;
$$ language plpgsql security definer;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.criar_perfil_novo_usuario();

-- ------------------------------------------------------------
-- MOTORISTAS (dados extras de quem é motorista)
-- ------------------------------------------------------------
create table if not exists motoristas (
  id uuid primary key references perfis(id) on delete cascade,
  matricula_moto text,
  modelo_moto text,
  aprovado boolean not null default false,
  disponivel boolean not null default false,
  created_at timestamptz default now()
);

-- ------------------------------------------------------------
-- CORRIDAS (pedidos de viagem)
-- ------------------------------------------------------------
create table if not exists corridas (
  id uuid primary key default gen_random_uuid(),
  passageiro_id uuid references auth.users(id) on delete cascade,
  motorista_id uuid references auth.users(id),
  origem text not null,
  destino text not null,
  distancia_km numeric(6,2),
  preco_estimado numeric(10,2),
  status text not null default 'procurando', -- procurando | aceita | em_andamento | concluida | cancelada
  created_at timestamptz default now()
);

-- ------------------------------------------------------------
-- CONFIGURAÇÃO DE TARIFA (editável pelo admin)
-- ------------------------------------------------------------
create table if not exists tarifas (
  id integer primary key default 1,
  tarifa_base numeric(10,2) not null default 30.00, -- MT
  tarifa_por_km numeric(10,2) not null default 15.00, -- MT
  constraint uma_linha check (id = 1)
);
insert into tarifas (id, tarifa_base, tarifa_por_km) values (1, 30.00, 15.00)
  on conflict (id) do nothing;

-- ============================================================
-- ROW LEVEL SECURITY
-- ============================================================
alter table perfis enable row level security;
alter table motoristas enable row level security;
alter table corridas enable row level security;
alter table tarifas enable row level security;

-- Perfis
create policy "perfis_ver_proprio" on perfis for select using (auth.uid() = id);
create policy "perfis_editar_proprio" on perfis for update using (auth.uid() = id);
create policy "perfis_admin_tudo" on perfis for all
  using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');

-- Motoristas: qualquer autenticado pode ver motoristas aprovados (passageiro precisa disso);
-- motorista edita o próprio cadastro; admin gerencia tudo
create policy "motoristas_ver_aprovados" on motoristas for select using (aprovado = true);
create policy "motoristas_ver_proprio" on motoristas for select using (auth.uid() = id);
create policy "motoristas_criar_proprio" on motoristas for insert with check (auth.uid() = id);
create policy "motoristas_editar_proprio" on motoristas for update using (auth.uid() = id);
create policy "motoristas_admin_tudo" on motoristas for all
  using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');

-- Corridas: passageiro cria e vê as próprias; motoristas autenticados veem corridas em aberto
-- e as que já são deles; qualquer envolvido (ou admin) pode atualizar o status
create policy "corridas_criar_propria" on corridas for insert with check (auth.uid() = passageiro_id);
create policy "corridas_ver_envolvidos" on corridas for select
  using (auth.uid() = passageiro_id or auth.uid() = motorista_id or status = 'procurando');
create policy "corridas_atualizar_envolvidos" on corridas for update
  using (auth.uid() = passageiro_id or auth.uid() = motorista_id or status = 'procurando');

-- Tarifas: leitura pública (pra calcular preço estimado), edição só de autenticado (admin)
create policy "tarifas_leitura_publica" on tarifas for select using (true);
create policy "tarifas_editar_admin" on tarifas for update using (auth.role() = 'authenticated');
