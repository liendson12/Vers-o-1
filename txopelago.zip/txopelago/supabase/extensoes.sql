-- ============================================================
-- TXOPELAGO MOZ — extensões (rode depois do schema.sql)
-- ============================================================

-- Comissão da plataforma (%) e taxa de cancelamento, editáveis pelo admin
alter table tarifas add column if not exists comissao_percentual numeric(5,2) not null default 15.00;
alter table tarifas add column if not exists taxa_cancelamento numeric(10,2) not null default 0.00;

-- Corridas: método de pagamento e se já foi avaliada
alter table corridas add column if not exists metodo_pagamento text default 'mpesa'; -- mpesa | emola
alter table corridas add column if not exists avaliada boolean default false;
alter table corridas add column if not exists codigo_promo text;
alter table corridas add column if not exists desconto numeric(10,2) default 0;

-- ------------------------------------------------------------
-- AVALIAÇÕES (passageiro avalia motorista, e vice-versa)
-- ------------------------------------------------------------
create table if not exists avaliacoes (
  id uuid primary key default gen_random_uuid(),
  corrida_id uuid references corridas(id) on delete cascade,
  avaliador_id uuid references auth.users(id),
  avaliado_id uuid references auth.users(id),
  nota integer not null check (nota between 1 and 5),
  comentario text,
  created_at timestamptz default now()
);

-- ------------------------------------------------------------
-- PAGAMENTOS (registro do método escolhido — M-Pesa / e-Mola)
-- IMPORTANTE: isto é um registro manual/preparatório. Não existe
-- nenhuma integração real com M-Pesa/e-Mola aqui — quando vocês
-- tiverem as credenciais oficiais, essa tabela já está pronta
-- para receber o retorno automático da API.
-- ------------------------------------------------------------
create table if not exists pagamentos (
  id uuid primary key default gen_random_uuid(),
  corrida_id uuid references corridas(id) on delete cascade,
  metodo text not null, -- mpesa | emola
  valor numeric(10,2) not null,
  status text not null default 'pendente', -- pendente | confirmado | falhou
  referencia text, -- para colar depois o ID de transação real da API
  created_at timestamptz default now()
);

-- ------------------------------------------------------------
-- PROMOÇÕES (códigos de desconto simples)
-- ------------------------------------------------------------
create table if not exists promocoes (
  id uuid primary key default gen_random_uuid(),
  codigo text unique not null,
  desconto_percentual numeric(5,2) not null default 10,
  ativo boolean not null default true,
  validade date,
  created_at timestamptz default now()
);

-- ============================================================
-- RLS das novas tabelas
-- ============================================================
alter table avaliacoes enable row level security;
alter table pagamentos enable row level security;
alter table promocoes enable row level security;

create policy "avaliacoes_criar_propria" on avaliacoes for insert with check (auth.uid() = avaliador_id);
create policy "avaliacoes_ver_relacionadas" on avaliacoes for select
  using (auth.uid() = avaliador_id or auth.uid() = avaliado_id or auth.role() = 'authenticated');

create policy "pagamentos_criar_autenticado" on pagamentos for insert with check (auth.role() = 'authenticated');
create policy "pagamentos_ver_autenticado" on pagamentos for select using (auth.role() = 'authenticated');
create policy "pagamentos_admin_atualizar" on pagamentos for update using (auth.role() = 'authenticated');

create policy "promocoes_leitura_publica" on promocoes for select using (true);
create policy "promocoes_admin_gestao" on promocoes for insert with check (auth.role() = 'authenticated');
create policy "promocoes_admin_update" on promocoes for update using (auth.role() = 'authenticated');
create policy "promocoes_admin_delete" on promocoes for delete using (auth.role() = 'authenticated');
