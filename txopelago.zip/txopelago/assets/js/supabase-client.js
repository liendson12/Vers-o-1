// ============================================================
// TXOPELAGO MOZ — cliente Supabase compartilhado
// ⚠️ SUBSTITUA os dois valores abaixo pelos do SEU projeto Supabase:
// Project Settings → API → Project URL / anon public key
// ============================================================
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const SUPABASE_URL = 'https://qrxwvprqohrbjgahalvv.supabase.co';
const SUPABASE_KEY = 'sb_publishable_nkHdwiMpqL5rffSO5XAo8w_6jXdJzJn';

export const supabase = createClient(SUPABASE_URL, SUPABASE_KEY);

// Exige sessão logada, senão manda para entrar.html
export async function requireLogin() {
  const { data: { session } } = await supabase.auth.getSession();
  if (!session) {
    window.location.href = 'entrar.html';
    return null;
  }
  return session;
}

// Busca o perfil (nome, tipo, telefone) do usuário logado
export async function getPerfil(userId) {
  const { data } = await supabase.from('perfis').select('*').eq('id', userId).single();
  return data;
}

export function formatMT(value) {
  return Number(value || 0).toLocaleString('pt-MZ', { maximumFractionDigits: 2 }) + ' MT';
}

export function formatDateHora(iso) {
  if (!iso) return '';
  return new Date(iso).toLocaleString('pt-PT', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' });
}
